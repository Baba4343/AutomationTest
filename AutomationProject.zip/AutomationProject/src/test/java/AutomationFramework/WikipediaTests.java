package AutomationFramework;

import org.junit.Test;
import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

/**
 * Created by Ali Balkot on 05/10/2016.
 */

public class WikipediaTests extends WikiHome {

    @Test
    public void task1() {
        String expectedTitle = "Wikipedia, the free encyclopedia"; // << The title we are expecting
            String actualTitle = driver.getTitle(); // << Obtaining the pages actual title
                Assert.assertEquals(expectedTitle, actualTitle); // << Carrying out a comparison between the two
    }

    @Test
    public void task2() {
        WebElement searchBox = driver.findElement(By.id("searchInput")); // << searching for the search box
        searchBox.sendKeys("furry rabbits"); // << typing in the search box

            try {
                Thread.sleep(5000); // Waits for 5 seconds
            } catch (InterruptedException e) {
                e.printStackTrace();
            }

        JavascriptExecutor jse = (JavascriptExecutor) driver;
        jse.executeScript("document.getElementById('searchButton').click();"); // Javascript is used to execute a click (can be more reliable to use JS)

        Boolean isPresent = driver.findElements(By.className("searchdidyoumean")).size() > 0; // << Checks to see if the "did you mean" element is present on the page
        Assert.assertTrue(isPresent);

        String actualText = driver.findElement(By.className("searchdidyoumean")).getText(); // << Verify the element contains specific text
        Assert.assertTrue(actualText.contains("Did you mean:"));
    }

    @Test
    public void task3() {

        JavascriptExecutor jse = (JavascriptExecutor) driver;
        jse.executeScript("document.getElementById('searchButton').click();"); // Javascript is used to execute a click

        int liCount = driver.findElements(By.className("mw-search-result-heading")).size(); // << Gets the number of search results
        System.out.println(liCount);

        int expectedCount = 20;

        Assert.assertEquals(liCount, expectedCount); // << Compares the number of search results with how many we are expecting

        if (liCount == 20);
        {
            driver.findElement(By.xpath("//*[@id=\"mw-search-DYM-suggestion\"]/em")).click();

            WebDriverWait wait = new WebDriverWait(driver, 5);
            wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//*[@id=\"mw-content-text\"]/div/ul/li[1]/div[1]/a"))).click(); // << Selenium will wait 5 seconds to find this element

            String expectedTitle = "List of fictional rabbits and hares - Wikipedia, the free encyclopedia";
            String actualTitle = driver.getTitle();
            Assert.assertEquals(expectedTitle, actualTitle);

            String contentPresent = driver.findElement(By.xpath("//*[@id=\"toctitle\"]/h2")).getText();
            String contentExpected = "Contents";
            Assert.assertEquals(contentPresent, contentExpected);
        }
    }
}