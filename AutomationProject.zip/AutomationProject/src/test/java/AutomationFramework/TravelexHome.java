package AutomationFramework;

import org.junit.AfterClass;
import org.junit.BeforeClass;
import org.openqa.selenium.Dimension;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

/**
 * Created by Ali Balkot on 05/10/2016.
 */

public class TravelexHome {

    public static WebDriver driver;

    @BeforeClass
    public static void runTravelex()
    {
        System.setProperty("webdriver.chrome.driver", "/Users/Baba/Documents/webdrivers/chrome/chromedriver");
        driver = new ChromeDriver();
        driver.get("https://www.travelex.co.uk/");
        driver.manage().window().setSize(new Dimension(250,1050)); // << Sets the browser size (height + width) that is specific for this test
    }

    @AfterClass
    public static void endTravelexSession()
    {
        try {
            Thread.sleep(10000); // Waits for 10 seconds before closing the browser after the tests have run
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        driver.close();
    }
}