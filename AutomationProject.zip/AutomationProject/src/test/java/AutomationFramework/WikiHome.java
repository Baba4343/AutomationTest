package AutomationFramework;

import org.junit.AfterClass;
import org.junit.BeforeClass;
import org.junit.Test;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.remote.server.handler.WebDriverHandler;

/**
 * Created by Ali Balkot on 05/10/2016.
 */

public class WikiHome {

    public static WebDriver driver;

    @BeforeClass
    public static void runWikipedia()
    {
        System.setProperty("webdriver.chrome.driver", "/Users/Baba/Documents/webdrivers/chrome/chromedriver");
        driver = new ChromeDriver();
        driver.get("https://en.wikipedia.org");
        driver.manage().window().maximize();
    }

    @AfterClass
    public static void endWikiSession()
    {
        try {
            Thread.sleep(10000); // Waits for 10 seconds before closing the browser after the tests have run
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        driver.close();
    }
}