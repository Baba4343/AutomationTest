package AutomationFramework;

import org.junit.Assert;
import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.Dimension;
import org.openqa.selenium.WebElement;

import static com.sun.jmx.snmp.EnumRowStatus.active;

/**
 * Created by Ali Balkot on 05/10/2016.
 */

public class TravelexTests extends TravelexHome {

    @Test
    public void task1() {

        try {
            Thread.sleep(5000); // Waits for 5 seconds
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

        driver.findElement(By.xpath("/html/body/div[1]/div[2]/div/section[2]/article/div[1]/ul/li[2]/button")).click(); // << Clicks the second button

        try {
            Thread.sleep(3000); // Waits for 5 seconds
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

        driver.findElement(By.xpath("/html/body/div[1]/div[2]/div/section[2]/article/div[1]/ul/li[3]/button")).click(); // << Clicks the third button

        String itemPosition = driver.findElement(By.xpath("/html/body/div[1]/div[2]/div/section[2]/article/div[1]/ul/li[3]/button")).getText(); // << Gets the items position number
        System.out.println(itemPosition);

        int expectedPosition = 3;
        int actualPosition = Integer.parseInt(itemPosition);

        Assert.assertSame(expectedPosition, actualPosition); // << Here we assert that we are indeed on the third item
    }
}